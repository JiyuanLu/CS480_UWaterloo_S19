I implemented my programs on Windows 10.

A2q1:
To run the python script in command line:
In "Q1_Linear_Regression" directory, type: python main.py

A2q4:
To run the python script in command line:
In "Q4_SVM_With_Kernels" directory, type: python main.py