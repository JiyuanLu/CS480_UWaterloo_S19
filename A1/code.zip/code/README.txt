I implemented my programs on Windows 10.

A1q2:
To run the python script in command line:
In "KNN" directory, type: python main.py

A1q4:
To run the python script in command line:
In "Empirical_Evaluation" directory, type: python main.py